﻿using RegApp.AppFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RegLibrary;
using CaptchaLibrary;

namespace RegApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        

        public MainWindow()
        {
            InitializeComponent();

            DbConnect.entObj = new RegistrationEntities();
            BtnCreate.IsEnabled = false;
            BtnCaptcha.IsEnabled = false;
            //CaptchaLabel.Text = " ";
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            if (DbConnect.entObj.User.Count(x => x.Name == TxbLogin.Text) > 0)
            {
                MessageBox.Show("Такой пользователь уже есть!",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                return;
            }
            else
            {

                if (RegistrationClass.isItEmail(TxbLogin.Text, RegLibrary.RegistrationClass.emailPattern) == false)
                {
                    MessageBox.Show("Неверный формат почты",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                }
                else if (RegistrationClass.isItPassword(PsbPassword.Password, RegLibrary.RegistrationClass.passwordPattern) == false)
                {
                    MessageBox.Show("Неверный формат пароля",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                }
                else
                {
                    try
                    {
                        User userObj = new User()
                        {
                            Name = TxbLogin.Text,
                            Password = PsbPassword.Password,
                            IdRole = 1
                        };

                        DbConnect.entObj.User.Add(userObj);
                        DbConnect.entObj.SaveChanges();

                        MessageBox.Show("Пользователь создан",
                                   "Уведомление",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка работы приложения: " + ex.Message.ToString(),
                                    "Критический сбой работы приложения",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Warning);
                    }
                }
            }
        }

        private void PsbPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (TxbPassword.Text == PsbPassword.Password)
            {
                PsbPassword.Background = Brushes.LightBlue;
                PsbPassword.BorderBrush = Brushes.Blue;

                CaptchaLabel.Text = CaptchaLibrary.CaptchaClass.Captcha(6);
                BtnCaptcha.IsEnabled = true;
            }
            else
            {
                BtnCreate.IsEnabled = false;
                BtnCaptcha.IsEnabled = false;
                PsbPassword.Background = Brushes.LightCoral;
                PsbPassword.BorderBrush = Brushes.Red;
            }
        }

        private void TxbLogin_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CaptchaBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (CaptchaBox.Text == CaptchaLabel.Text)
            {
                CaptchaBox.Background = Brushes.LightBlue;
                CaptchaBox.BorderBrush = Brushes.Blue;
            }
            else
            {
                BtnCreate.IsEnabled = false;
                CaptchaBox.Background = Brushes.LightCoral;
                CaptchaBox.BorderBrush = Brushes.Red;
            }
        }

        private void BtnCaptcha_Click(object sender, RoutedEventArgs e)
        {
            if (CaptchaBox.Text == CaptchaLabel.Text)
            {
                BtnCreate.IsEnabled = true;
                MessageBox.Show("Капча введена верно!",
                                  "Уведомление",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
            }
            else
            {
                BtnCreate.IsEnabled = false;
                MessageBox.Show("Неверно введена капча!",
                                "Ошибка!",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);

                CaptchaLabel.Text = CaptchaLibrary.CaptchaClass.Captcha(6);
            }
        }
    }
}
