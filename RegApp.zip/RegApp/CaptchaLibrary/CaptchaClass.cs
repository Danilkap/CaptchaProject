﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CaptchaLibrary
{
    public class CaptchaClass
    {
        public static string Captcha(int a) 
        { 
            Random random = new Random();

            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$*№";
            var stringChars = new char[6];

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            var finalString = new String(stringChars);
            return finalString;
        }

        public static int GetCaptchaLength(string captcha)
        {
            int result = 0;
            if (Math.Min(captcha.Length, 6) == 6)
            {
                result++;
            }
            return result;
        }

        public static int GetCaptchaLowerCase(string captcha)
        {
            int result = 0;
            if (Regex.Match(captcha, "[a-z]").Success)
            {
                result++;
            } 
            return result;
        }
        public static int GetCaptchaUpperCase(string captcha)
        {
            int result = 0;
            if (Regex.Match(captcha, "[A-Z]").Success)
            {
                result++;
            }
            return result;
        }
        public static int GetCaptchaNumbers(string captcha)
        {
            int result = 0;
            if (Regex.Match(captcha, "[0-9]").Success)
            {
                result++;
            }
            return result;
        }
        public static int GetCaptchaSpecialSymbols(string captcha)
        {
            int result = 0;
            if (Regex.Match(captcha, "[\\!\\@\\#\\$\\*\\№]").Success)
            {
                result++;
            }
            return result;
        }
    }
}
