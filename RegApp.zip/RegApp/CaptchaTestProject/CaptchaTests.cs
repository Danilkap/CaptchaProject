﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RegApp;

namespace CaptchaTestProject
{
    [TestClass]
    public class CaptchaTests
    {
        [TestMethod]
        public void GetCaptchaStrength_AllChars_1Point()
        {
            string captcha = "nD$rA1";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaLength(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaLowerCase_AllChars_1Point()
        {
            string captcha = "nD$rA1";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaLowerCase(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaUpperCase_AllChars_1Point()
        {
            string captcha = "nsD$rA1";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaUpperCase(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaNumbers_AllChars_1Point()
        {
            string captcha = "nD$rA1";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaNumbers(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaSpecialSymbols_AllChars_1Point()
        {
            string captcha = "nD$rA1";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaSpecialSymbols(captcha);
            Assert.AreEqual(expected, actual);
        }
    }
}
